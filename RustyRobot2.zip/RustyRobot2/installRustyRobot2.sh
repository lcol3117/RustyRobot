#!/bin/bash

cdir=$(pwd)
echo "WELCOME TO THE RUSTYROBOT INSTALLER!"
echo "Please ensure that the RustyRobot.rs file alone is in this directory. "
echo "If it is not, press Ctrl+C to halt installation. "
echo "Then download the RustyRobot.rs file and put it in a new directory. "
echo "Then repeat this installation proccess there. "
echo "You have 10 seconds to halt the installation now. "
sleep 5
echo "You have 5 seconds to halt the installation now. "
sleep 3
echo "You have 2 seconds to halt the installation now. "
sleep 2
echo "Installing RustyRobot here, now..."
echo "Adding runRustyRobot.sh script..."
a='echo "Building currentRustyRobot.rs file...";
cat rustyRobot.rs $1 > currentRustyRobot.rs;
echo "Done, Compiling with rustc...";
rustc -v currentRustyRobot.rs;
echo "Done, running machine code...";
./currentRustyRobot;
echo "Done, cleaning up machine code...";
rm currentRustyRobot;
echo "Done"'
touch runRustyRobot.sh
sleep 1
echo ${a} > runRustyRobot.sh
echo "Done, adding temp currentRustyRobot.rs rust file..."
touch currentRustyRobot.rs
echo "Done, updating .bashrc with runrsbot command alias..."
aliascode="alias runrsbot=\"bash runRustyRobot.sh\""
echo $aliascode >> ~/.bashrc
sleep 1
echo "Done, resolving alias in current shell..."
alias runrsbot="bash runRustyRobot.sh"
echo "Done."
echo "Now, to run code, use runrsbot [FILENAME]."
sleep 3
echo "Removing this file..."
rm $0
