#[allow(non_snake_case)]
#[allow(unused_variables)]

use std::io;
use std::io::*;
use std::{thread, time};

fn main() {
  let mut the_robot: Robot = Robot {
    teamnumber: 117,
    state: getBlankRobotState(),
  };
  println!("Type enable and press enter to enable robot. ");
  let mut uin = String::new();
  io::stdin()
    .read_line(&mut uin)
    .expect("error: uin failed");
  let rluin = uin
    .split_whitespace()
    .collect::<String>();
  if rluin == "enable" {
    println!("Attempting to enable robot");
    the_robot.enable();
  } else {
    println!("The robot was not enabled. ");
  }
}

fn getBlankRobotState() -> RobotState {
  RobotState {
    dio: vec![IOEnum::Unknown, IOEnum::Unknown],
    din: vec![false, false],
    dout: vec![false, false],
    i2c: I2C {
      sda: false,
      scl: false
    },
    spi: SPI {
      mosi: false,
      miso: false,
      sck: false,
      chipselect: vec![false],
    },
    rsl: false,
  }
}

struct Robot {
  teamnumber: i32,
  state: RobotState,
}

impl Robot {
  fn enable(&mut self) -> Done {
    println!("Enabling...");
    self.state.rsl = true;
    println!("RSL on is {}. ", self.state.rsl);
    self.runProgram();
    self.disable();
    Done
  }
  fn disable(&mut self) -> Done {
    println!("Disabling...");
    self.state.rsl = false;
    println!("RSL on is {}. ", self.state.rsl);
    Done
  }
  fn setDIO(&mut self, pin: u32, iostate: IOEnum) -> Done {
    let index: usize = pin as usize;
    self.state.dio[index] = iostate;
    if iostate.isInput() {
      println!("Configured pin {} as an Input. ", pin);
    } else {
      println!("Configured pin {} as an Output. ", pin);
    }
    Done
  }
  fn readInput(&mut self, pin: u32) -> bool {
    let index: usize = pin as usize;
    println!("Enter state for pin ");
    println!("{:?}", pin);
    let mut uin = String::new();
    io::stdin()
      .read_line(&mut uin)
      .expect("error: uin failed");
    let rluin = uin
      .split_whitespace()
      .collect::<String>();
    if rluin == "true" {
      self.state.din[index] = true;
    } else {
      self.state.din[index] = false;
    }
    assert!(self.state.dio[index].isInput());
    println!("Read Input {}, ", pin);
    println!("it was {}. ", self.state.din[index]);
    self.state.din[index]
  }
  fn setOutput(&mut self, pin: u32, val: bool) -> Done {
    let index: usize = pin as usize;
    assert!(self.state.dio[index].isOutput());
    self.state.dout[index] = val;
    println!("Set Output {}, ", pin);
    println!("it is now {}. ", val);
    Done
  }
  fn getTimestamp(&self) -> time::Instant {
    time::Instant::now()
  }
  fn waitMS(&self, ms: u32) -> Done {
    let ms64: u64 = ms as u64;
    let sleepduration: time::Duration = time::Duration::from_millis(ms64);
    thread::sleep(sleepduration);
    Done
  }
}

struct RobotState {
  dio: Vec<IOEnum>,
  din: Vec<bool>,
  dout: Vec<bool>,
  i2c: I2C,
  spi: SPI,
  rsl: bool,
}

struct I2C {
  sda: bool,
  scl: bool,
}

struct SPI {
  mosi: bool,
  miso: bool,
  sck: bool,
  chipselect: Vec<bool>,
}

struct Done;

enum IOEnum {
  Input,
  Output,
  Unknown,
}

impl IOEnum {
  fn isInput(&self) -> bool {
    match *self {
      IOEnum::Input => true,
      _ => false,
    }
  }
  fn isOutput(&self) -> bool {
    match *self {
      IOEnum::Output => true,
      _ => false,
    }
  }
}

impl Copy for IOEnum {}

impl Clone for IOEnum {
  fn clone(&self) -> Self {
    *self
  }
}
